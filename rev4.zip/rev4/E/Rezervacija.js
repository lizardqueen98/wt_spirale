const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
	return sequelize.define(
		'Rezervacija',
		{
			id: {
				type: Sequelize.INTEGER,
				autoIncrement: true,
				primaryKey: true
			},
			termin: {
				type: Sequelize.INTEGER,
				// references: 'termini',
				// referencesKey: 'id',				
				unique: true
			},
			sala: {
				type: Sequelize.INTEGER//,
				// references: 'sale',
				// referencesKey: 'id'
			},
			osoba: {
				type: Sequelize.INTEGER//,
				// references: 'osobe',
				// referencesKey: 'id'
			}
		}
	);
}