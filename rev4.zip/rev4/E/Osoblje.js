const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
	return sequelize.define(
		'Osoblje',
		{
			id: {
				type: Sequelize.INTEGER,
				autoIncrement: true,
				primaryKey: true
			},
			ime: {
				type: Sequelize.STRING
			},
			prezime: {
				type: Sequelize.STRING
			},
			uloga: {
				type: Sequelize.STRING
			}
		}
	);
}