const db = require('./db.js');
// Izbiris sve prvo!!
function inicirajBazu() {
	db.sequelize.sync({force:true}).then(function() {
		var nizPromisea = []
		return new Promise(function(resolve, reject) {
			// Osoblje
			nizPromisea.push(db.Osoblje.create({ime: 'Neko', prezime: 'Nekić', uloga: 'profesor'}));
			nizPromisea.push(db.Osoblje.create({ime: 'Drugi', prezime: 'Neko', uloga: 'asistent'}));
			nizPromisea.push(db.Osoblje.create({ime: 'Test', prezime: 'Test', uloga: 'asistent'}));
			Promise.all(nizPromisea).then(function(osoblje) {
				nizPromisea = [];
				nizPromisea.push(db.Termin.create({redovni: false, dan: null, datum: '01.01.2020', semestar: null, pocetak: "12:00", kraj: "13:00"}));
				nizPromisea.push(db.Termin.create({redovni: true, dan: 0, datum: null, semestar: 0, pocetak: "13:00", kraj: "14:00"}));
				Promise.all(nizPromisea).then(function(termini) {
					nizPromisea = [];
					var osoba1 = osoblje.filter(function(a){return a.ime === 'Neko'})[0];
					var osoba2 = osoblje.filter(function(a){return a.ime === 'Drugi'})[0];
					nizPromisea.push(db.Sala.create({naziv: '1-11', zaduzenaOsoba: osoba1.id}));
					nizPromisea.push(db.Sala.create({naziv: '1-15', zaduzenaOsoba: osoba2.id}));
					Promise.all(nizPromisea).then(function(sale) {
						nizPromisea = [];
						var termin1 = termini.filter(function(a){return a.redovni === false})[0];
						var termin2 = termini.filter(function(a){return a.redovni === true})[0];
						var sala1 = sale.filter(function(a){return a.naziv === '1-11'})[0];
						var osoba3 = osoblje.filter(function(a){return a.ime === 'Test'})[0];
						nizPromisea.push(db.Rezervacija.create({termin: termin1.id, sala: sala1.id, osoba: osoba1.id}));
						nizPromisea.push(db.Rezervacija.create({termin: termin2.id, sala: sala1.id, osoba: osoba3.id}));
						Promise.all(nizPromisea).then(function() {
							console.log("Popunjena baza!");
						}).catch(function(err){console.log("Rez " + err);});
					});
				});
			});
		});
	});
}

module.exports = inicirajBazu;
