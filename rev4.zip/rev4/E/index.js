const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const db = require('./db.js');
const inic = require('./pokretanjeBaze.js');

const app = express();
app.use(express.static(path.join(__dirname + '/static')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
	res.sendFile(path.join(__dirname, 'pocetna.html'));
});

app.get('/zauzeca.json', (req, res) => {
	res.sendFile(path.join(__dirname, 'zauzeca.json'));
});

app.get('/osobljePodaci', (req, res) => {
	db.Osoblje.findAll(
	{include: [{model: db.Rezervacija, as: 'rezervacije',
		include: [{model: db.Sala, as: 'Sala'},
			{model: db.Termin, as: 'Termin'}]
	}]}
	).then(function(osoblje) {
		res.json(osoblje);
	})
;});

app.get('/osoblje', (req, res) => {
	db.Osoblje.findAll().then(function(osoblje) {
		res.json(osoblje);
	});
});

app.get('/rezervacije', (req, res) => {
	db.Rezervacija.findAll().then(function(rezervacije) {
		res.json(rezervacije);
	});
});

app.get('/termini', (req, res) => {
	db.Termin.findAll().then(function(termini) {
		res.json(termini);
	});
});

app.get('/zauzeca', (req, res) => {
	db.Rezervacija.findAll({
		include: [{model: db.Termin, as: 'Termin'},
			{model: db.Osoblje, as: 'Osoba'},
			{model: db.Sala, as: 'Sala'}]
	}).then(function(data){
		res.json(data);
	});
});

app.get('/pocetna', (req, res) => {
	res.sendFile(path.join(__dirname, 'pocetna.html'));
});

app.get('/sale', (req, res) => {
	res.sendFile(path.join(__dirname, 'sale.html'));
});

app.get('/unos', (req, res) => {
	res.sendFile(path.join(__dirname, 'unos.html'));
});

app.get('/rezervacija', (req, res) => {
	res.sendFile(path.join(__dirname, 'rezervacija.html'));
});

app.get('/osobe', (req, res) => {
	res.sendFile(path.join(__dirname, 'osoblje.html'));
});

app.get('/slike/:n', (req, res) => {
	var rezultat = {kraj: false, putanje: []};
	var n = req.params.n;
	traziSlike(res, Number(n), 0, rezultat);
});

function traziSlike(res, n, i, rezultat) {
	fs.access("static/" + (n + i) + ".jpg", fs.constants.F_OK, function(err) {
		if (err) {
			// slika ne postoji
			// oznacavamo kraj slika
			rezultat.kraj = true;
		} else {
			// dodajemo putanju slike u rezultat
			rezultat.putanje.push((n + i) + ".jpg");
		}
		
		if (err || i === 2) { // nasli smo trecu ili zadnju sliku
			res.send(rezultat);
		} else {
			// nastavljamo rekurzivne pozive
			traziSlike(res, n, i + 1, rezultat);
		}
	});
}

function noviTermin(podaci) {
	var t = new db.Termin();
	t.pocetak = podaci.pocetak;
	t.kraj = podaci.kraj;
	t.redovni = podaci.periodicno;
	if (podaci.periodicno === "true") {
		t.dan = podaci.dan;
		if (podaci.semestar === "zimski" || podaci.semestar === 0) {
			t.semestar = 0;
		} else {
			t.semestar = 1;
		}
		
	} else {
		t.dan = null;
		t.datum = podaci.datum;
		t.semestar = null;
	}
	return t;
}


app.post('/dodajZauzece', (req, res) => {
	var tijelo = req.body;
	var t = noviTermin(tijelo);
	var novaRez = new db.Rezervacija;
	
	db.Sala.findOne({ where: { naziv: tijelo.naziv }}).then(function(sala) {
		novaRez.sala = sala.id;
		db.Osoblje.findOne({ where: { ime: tijelo.predavac.split(" ")[0], prezime: tijelo.predavac.split(" ")[1] }}).then(function(osoba){
			novaRez.osoba = osoba.id;
			db.Termin.create({redovni: t.redovni, dan: t.dan, datum: t.datum, semestar: t.semestar, pocetak: t.pocetak, kraj: t.kraj}).then(function(termin) {
				novaRez.termin = termin.id;
				
				db.Rezervacija.create({termin: novaRez.termin, sala: novaRez.sala, osoba: novaRez.osoba}).then(function() {
					// vracamo podatke
					db.Rezervacija.findAll({
						include: [{model: db.Termin, as: 'Termin'},
							{model: db.Osoblje, as: 'Osoba'},
							{model: db.Sala, as: 'Sala'}]
					}).then(function(data){
						//obradiPotencijalnoZauzece(res, tijelo, data);
						res.json(data);
					});
				});
			});
		});
	});
});
/*
function obradiPotencijalnoZauzece(res, tijelo, data) {
	// pravimo novo zauzece koristeci podatke
	var periodicno = tijelo.periodicno;
	var novoZauzece;
	if (periodicno) {
		novoZauzece = {"dan": Number(tijelo.dan), "semestar": tijelo.semestar, "pocetak": tijelo.pocetak, "kraj": tijelo.kraj, 
		"naziv": tijelo.naziv, "predavac": tijelo.predavac};
	} else {
		novoZauzece = {"datum": tijelo.datum, "pocetak": tijelo.pocetak, "kraj": tijelo.kraj, "naziv": tijelo.naziv, 
		"predavac": tijelo.predavac};
	}
	
	db.Rezervacija.findAll({
		include: [{model: db.Termin, as: 'Termin'},
			{model: db.Osoblje, as: 'Osoba'},
			{model: db.Sala, as: 'Sala'}]
	}).then(function(data){
		
		res.json(data);
	});
	
}

function pretvoriUZauzeca(niz) {
	var periodicna = [];
	var vanredna = [];
	for (var i = 0; i < niz.length; i++) {
		var z = {}; // zauzece
		var r = niz[i]; // rezervacija
		// postavljanje podataka
		z.pocetak = r.Termin.pocetak;
		z.kraj = r.Termin.kraj;
		z.naziv = r.Sala.naziv;
		z.predavac = r.Osoba.ime + " " + r.Osoba.prezime;
		if (r.Termin.redovni) {
			z.dan = r.Termin.dan;
			if (r.Termin.semestar == 0) {
				z.semestar = "zimski";
			} else if (r.Termin.semestar == 1) {
				z.semestar = "ljetni";
			}
			periodicna.push(z);
		} else {
			z.datum = r.Termin.datum;
			vanredna.push(z)
		}
	}
	return {"periodicna": periodicna, "vanredna": vanredna};
}
*/

app.post('/dodajVanrednoZauzece1', (req, res) => {
	var tijelo = req.body;
	var novoZauzece = {"datum": tijelo.datum, "pocetak": tijelo.pocetak, "kraj": tijelo.kraj, 
		"naziv": tijelo.naziv, "predavac": tijelo.predavac};
	// Asinhrono dobavljanje i koristenje podataka
	fs.readFile('zauzeca.json', function obradiVanredniZahtjev(err, data) {
		if (err) {
			console.log(err);
		} else {
			var zauzeca = JSON.parse(data);
			if (!testirajPreklapanja(novoZauzece, false, zauzeca)) {
				// nema preklapanja
				// dodati novo vanredno zauzece
				zauzeca.vanredna.push(novoZauzece);
				var jsonZaUpisati = JSON.stringify(zauzeca);
				// Asinhrono upisivanje i vracanje podataka
				fs.writeFile('zauzeca.json', jsonZaUpisati, 'utf8', (err) => {
					if (err) {
						throw err;
					} else {
						res.sendFile(path.join(__dirname, 'zauzeca.json'));
					}
				});
			} else {
				// ima preklapanja
				// status konflikta sa stanjem na serveru
				res.status(409);
				var porukaGreske = "Nije moguće rezervisati salu " + novoZauzece.naziv + " za navedeni datum " + 
					novoZauzece.datum + " i termin od " + novoZauzece.pocetak + " do " + novoZauzece.kraj + "!";
				res.send(porukaGreske);
				
			}
		}
	});
});

// iniciraj bazu
inic();

// pokreni server
app.listen(8080, () => {});


// pomocne funkcije

function dajStringDatuma(d, m, y) {
	var d = new Date(y, m, d);
	var str = "";
	if (d.getDate() < 10) {
		str += "0" + d.getDate();
	} else {
		str += d.getDate();
	}
	str += ".";
	if (d.getMonth() + 1 < 10) {
		str += "0" + (d.getMonth() + 1);
	} else {
		str += d.getMonth() + 1;
	}
	return str + "." + d.getFullYear();
}

function testirajPreklapanja(novoZauzece, periodicno, zauzeca) {
	var p = zauzeca.periodicna;
	var v = zauzeca.vanredna;
	// testiramo preklapanja sa periodicnim zauzecima
	for (var i = 0; i < p.length; i++) {
		if (periodicno) {
			if (testirajPerPer(novoZauzece, p[i])) {
				return true;
			}
		} else {
			if (testirajPerVan(p[i], novoZauzece)) {
				return true;
			}
		}
	}
	
	for	(var i = 0; i < v.length; i++) {
		if (periodicno) {
			if (testirajPerVan(novoZauzece, v[i])) {
				return true;
			}
		} else {
			if (testirajVanVan(novoZauzece, v[i])) {
				return true;
			}
		}
	}
	return false;
}

function testirajPerPer(p1, p2) {
	// testiramo jednakost naziva sale, semestra, i dana
	if ((p1.naziv != p2.naziv) || (p1.semestar != p2.semestar) || (p1.dan != p2.dan)) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((p1.pocetak <= p2.pocetak && p1.kraj > p2.pocetak) || (p1.pocetak >= p2.pocetak && p1.pocetak < p2.kraj))) {
		return false;
	}
	return true;
}

function testirajVanVan(v1, v2) {
	// testiramo jednakost naziva sale i datuma
	if ((v1.naziv != v2.naziv) || (v1.datum != v2.datum)) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((v1.pocetak <= v2.pocetak && v1.kraj > v2.pocetak) || (v1.pocetak >= v2.pocetak && v1.pocetak < v2.kraj))) {
		return false;
	}
	return true;
}

function testirajPerVan(p, v) {
	// testiramo jednakost naziva sale
	if ((p.naziv != v.naziv)) {
		return false;
	}
	// provjera da li mjesec pripada semestru
	if (p.semestar === "zimski" && (v.mjesec > 0 || v.mjesec < 9)) {
			return false;
		}
	if (p.semestar === "ljetni" && (v.mjesec < 1 || v.mjesec > 5)) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((p.pocetak <= v.pocetak && p.kraj > v.pocetak) || (p.pocetak >= v.pocetak && p.pocetak < v.kraj))) {
		return false;
	}
	if (p.dan != dajRedniBrojDana(v.datum)) {
		return false;
	}
	return true;
}

function dajRedniBrojDana(str) {
	var date = new Date();
	var dayofweek = new Date(Number(str.substring(6, 10)), Number(str.substring(3, 5)) - 1, 1).getDay();
	// dayofweek je redni broj u sedmici prvog dana mjeseca, pocevsi od nule
	dayofweek = (dayofweek + 6) % 7;
	// danUSedmici je redni broj dana u sedmici, pocevsi od nule
	var danUSedmici = (Number(str.substring(0, 2)) + dayofweek - 1) % 7;
	return danUSedmici;
}

