const Sequelize = require("sequelize");
const sequelize = new Sequelize('DBWT19', 'root', 'root', {
   host: "localhost",
   dialect: 'mysql',
   pool: {
       max: 5,
       min: 0,
       acquire: 30000,
       idle: 10000
   },
   logging: false
});

const db = {};

// importovanje modela
db.Osoblje = sequelize.import(__dirname + '/Osoblje.js');
db.Rezervacija = sequelize.import(__dirname + '/Rezervacija.js');
db.Termin = sequelize.import(__dirname + '/Termin.js');
db.Sala = sequelize.import(__dirname + '/Sala.js');

// definisanje relacija modela
db.Osoblje.hasMany(db.Rezervacija, {foreignKey: 'osoba', as: 'rezervacije'});
db.Sala.hasMany(db.Rezervacija, {foreignKey: 'sala', as: 'rezervacije'});

db.Sala.belongsTo(db.Osoblje, {foreignKey: 'zaduzenaOsoba', as: 'Osoba'});
db.Rezervacija.belongsTo(db.Termin, {foreignKey: 'termin', as: 'Termin'});
db.Rezervacija.belongsTo(db.Osoblje, {foreignKey: 'osoba', as: 'Osoba'});
db.Rezervacija.belongsTo(db.Sala, {foreignKey: 'sala', as: 'Sala'});

db.sequelize = sequelize;
module.exports = db;