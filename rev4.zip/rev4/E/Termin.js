const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
	return sequelize.define(
		'Termin',
		{
			id: {
				type: Sequelize.INTEGER,
				autoIncrement: true,
				primaryKey: true
			},
			redovni: {
				type: Sequelize.BOOLEAN
			},
			dan: {
				type: Sequelize.INTEGER
			},
			datum: {
				type: Sequelize.STRING
			},
			semestar: {
				type: Sequelize.INTEGER
			},
			pocetak: {
				type: Sequelize.TIME
			},
			kraj: {
				type: Sequelize.TIME
			}
		}
	);
}