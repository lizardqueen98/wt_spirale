const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
	return sequelize.define(
		'Sala',
		{
			id: {
				type: Sequelize.INTEGER,
				autoIncrement: true,
				primaryKey: true
			},
			naziv: {
				type: Sequelize.STRING
			},
			zaduzenaOsoba: {
				type: Sequelize.INTEGER//,
				// references: 'osobe',
				// referencesKey: 'id'
			}
		}
	);
}