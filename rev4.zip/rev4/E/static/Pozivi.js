
// DA LI MJESEC U KALENDAR.JS TREBA BITI TRENUTNI ILI NOV/DEC?

let Pozivi = (function() {
	//
	//ovdje idu privatni atributi
	//
	
	function ucitajOsobljeImpl(callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			obradiOdgovor(ajax, callback);
		}
		ajax.open('GET', 'osoblje');
		ajax.send();
	}
	
	function ucitajOsobljePodaciImpl(callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			obradiOdgovor(ajax, callback);
		}
		ajax.open('GET', 'osobljePodaci');
		ajax.send();
	}
	
	
	function ucitajDBPodatkeImpl(callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			obradiOdgovor(ajax, callback);
		}
		ajax.open('GET', 'zauzeca');
		ajax.send();
	}
	
	function obradiOdgovor(ajax, callback) {
		if (ajax.readyState == 4 && ajax.status == 200) {
			var res = JSON.parse(ajax.responseText);
			callback(res);
		}
		if (ajax.readyState == 4 && ajax.status == 404) {
			document.getElementById("body").innerHTML = "Greska: nepoznat URL";
		}
		
	}
	
	
	
	function ucitajJSONZauzecaImpl(callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				var res = JSON.parse(ajax.responseText);
				callback(res.periodicna, res.vanredna);
			}
			if (ajax.readyState == 4 && ajax.status == 404) {
				document.getElementById("body").innerHTML = "Greska: nepoznat URL";
			}
		}
		ajax.open('GET', "zauzeca.json");
		ajax.send();
	}
	
	function pokusajRezervisatiImpl(posiljka, periodicna, callbackUspjeh1, callbackUspjeh2, callbackUspjeh3, kalendarRef, mjesec, sala, 		pocetak, kraj, callbackNeuspjeh) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) { // termin je uspjesno rezervisan
				var res = JSON.parse(ajax.responseText);
				// ucitavamo podatke
				callbackUspjeh1(res);
				// bojimo dane na stranici
				callbackUspjeh2(kalendarRef, mjesec, sala, pocetak, kraj);
				// dodajemo event handlere danima
				callbackUspjeh3();
			} else if (ajax.readyState == 4 && ajax.status == 409) { // termin nije mogao biti rezervisan
				// prikazujemo poruku greske
				callbackNeuspjeh(ajax.responseText);				
			} else if (ajax.readyState == 4 && ajax.status == 404)
			{
				document.getElementById("body").innerHTML = "Greska: nepoznat URL";
			}
		}
		// slanje zahtjeva
		posaljiZahtjevZaRezervaciju(posiljka, periodicna, ajax);
	}
	
	// salje zahtjev za rezervaciju
	function posaljiZahtjevZaRezervaciju(posiljka, periodicna, ajax) {
		ajax.open('POST', "dodajZauzece");
		ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		if (periodicna) { // periodicno zauzece
			var rez = posiljka["rezervacija"];
			var datum = posiljka["datum"];
			ajax.send("dan=" + rez.dan + "&semestar=" + rez.semestar + "&pocetak=" + rez.pocetak + "&kraj=" + rez.kraj + 
				"&naziv=" + rez.naziv + "&predavac=" + rez.predavac + "&odabraniDan=" + datum.odabraniDan + "&mjesec=" +
				datum.mjesec + "&godina=" + datum.godina + "&periodicno=" + true);
		} else { // vanredno zauzece
			ajax.send("datum=" + posiljka.datum + "&pocetak=" + posiljka.pocetak + "&kraj=" + posiljka.kraj + 
				"&naziv=" + posiljka.naziv + "&predavac=" + posiljka.predavac + "&periodicno=" + false);
		}
	}
	
	function ucitajSlikeImpl(n, callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				var res = JSON.parse(ajax.responseText);
				callback(res);
			}
			if (ajax.readyState == 4 && ajax.status == 404) {
				document.getElementById("body").innerHTML = "Greska: nepoznat URL";
			}
		}
		// trazimo sljedece tri slike
		ajax.open('GET', "slike/" + (n + 3));
		ajax.send();
	}
	
	return {
		ucitajJSONZauzeca: ucitajJSONZauzecaImpl,
		pokusajRezervisati: pokusajRezervisatiImpl,
		ucitajSlike: ucitajSlikeImpl,
		ucitajOsoblje: ucitajOsobljeImpl,
		ucitajDBPodatke: ucitajDBPodatkeImpl,
		ucitajOsobljePodaci: ucitajOsobljePodaciImpl
	}
})();
