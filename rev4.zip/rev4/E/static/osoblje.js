var d;
var vrijeme;
var godina;
var mjesec;
var semestar;
var dayofweek;
var danUSedmici;

window.onload = onloadFunction;

function onloadFunction() {
	postaviTrenutnaVremena();
	Pozivi.ucitajOsobljePodaci(dodajOsoblje);
}

// svakih 30 sekundi provjeravamo rezervacijei azuriramo tabelu
setInterval(function(){
	// ispraznimo tabelu
	var tabelaOsoba = document.getElementById("tbody");
	while (tabelaOsoba.firstChild) {
		tabelaOsoba.removeChild(tabelaOsoba.firstChild);
	}
	onloadFunction();
}, 5000);

function postaviTrenutnaVremena() {
	d = new Date();
	vrijeme = d.toTimeString().substring(0, 5);
	godina = d.getFullYear();
	mjesec = d.getMonth();
	if (mjesec == 0 || mjesec > 8) {
		semestar = "zimski";
	} else if (mjesec > 0 && mjesec < 6) {
		semestar = "ljetni";
	}
	dayofweek = new Date(godina, mjesec, 1).getDay();
	dayofweek = (dayofweek + 6) % 7;
	// danUSedmici je redni broj dana u sedmici, pocevsi od nule
	danUSedmici = (d.getDate() + dayofweek - 1) % 7;
}

function osvjeziOsobe() {
	
}

function isprazniTabelu() {
	var tabelaOsoba = document.getElementById("tbody");
	for (var i = 0; tabelaOsoba.rows[i]; i++) {
		var row = tabelaOsoba.rows[i];
		for (var j = 0; row.cells[j]; j++) {
			var cell = row.cells[j];
			if (cell.tagName == "TD") {
				cell.textContent = "";
			}
		}
	}
}

function dodajOsobu(ime, prezime, uloga, sala) {
	var tabelaOsoba = document.getElementById("tbody");
	var el = document.createElement("tr");
	var el1 = document.createElement("td");
	var el2 = document.createElement("td");
	var el3 = document.createElement("td");
	var el4 = document.createElement("td");
	el1.textContent = ime;
	el1.className = "osoba";
	el2.textContent = prezime;
	el2.className = "osoba";
	el3.textContent = uloga;
	el3.className = "osoba";
	el4.textContent = sala;
	el4.className = "osoba";
	el.appendChild(el1);
	el.appendChild(el2);
	el.appendChild(el3);
	el.appendChild(el4);
	tabelaOsoba.appendChild(el);
}

function dodajOsoblje(podaci) {
	// update-ujemo trenutno vrijeme 
	postaviTrenutnaVremena();
	vrijeme = d.toTimeString().substring(0, 5);
	for(var i = 0; i < podaci.length; i++) {
		var osoba = podaci[i];
		var sala = "u kancelariji";
		
		// dodaj osnovne podatke
		// pogledaj da li postoji rezevacija sa terminom sada
		// ako postoji, dodaj salu rezervacije
		for (var j = 0; j < osoba.rezervacije.length; j++) {
			var poklapanje = false;
			if (osoba.rezervacije[j].Termin.redovni) {
				poklapanje = testRedovni(osoba.rezervacije[j].Termin);
			} else {
				poklapanje = testVanredni(osoba.rezervacije[j].Termin);
			}
			if (poklapanje) {
				sala = osoba.rezervacije[j].Sala.naziv;
				break;
			}
		}
		dodajOsobu(osoba.ime, osoba.prezime, osoba.uloga, sala);
	}
}

function testRedovni(termin) {
	var semestarTermina;
	if (termin.semestar == 0) {
		semestarTermina = "zimski";
	} else if (termin.semestar == 1) {
		semestarTermina = "ljetni";
	}
	// da li je semestar termina trenutni
	if (semestar != semestarTermina) {
		return false;
	}
	
	// testiramo preklapanja sati termina
	if (!((termin.pocetak <= vrijeme && termin.kraj > vrijeme) || (termin.pocetak >= vrijeme && termin.pocetak < vrijeme))) {
		return false;
	}
	// testiramo dan
	if (termin.dan != danUSedmici) {
		return false;
	}
	return true;	
}

function testVanredni(termin) {
	// testiramo preklapanje datuma
	if (termin.datum != dajStringDatuma(godina, mjesec, d.getDate())) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((termin.pocetak <= vrijeme && termin.kraj > vrijeme) || (termin.pocetak >= vrijeme && termin.pocetak < vrijeme))) {
		return false;
	}
	return true;
}
	
		
	function dajStringDatuma(d, m, y) {
		var d = new Date(y, m, d);
		var str = "";
		if (d.getDate() < 10) {
			str += "0" + d.getDate();
		} else {
			str += d.getDate();
		}
		str += ".";
		if (d.getMonth() + 1 < 10) {
			str += "0" + (d.getMonth() + 1);
		} else {
			str += d.getMonth() + 1;
		}
		return str + "." + d.getFullYear();
}
	

