
var odabraniDan = null;
var godina = 2020;

window.onload = onloadFunction;

function onloadFunction() {	
	Pozivi.ucitajDBPodatke(ucitajDBZauzeca);
	Pozivi.ucitajOsoblje(dodajOsoblje);
}

function dodajOsoblje(osobe) {
	console.log("dodajOsoblje");
	var osobeDropdown = document.getElementById("osobaDropdown");
	for (var i = 0; i < osobe.length; i++) {
		var el = document.createElement("option");
		el.textContent = osobe[i].ime + " " + osobe[i].prezime;
		el.value = osobe[i].id;
		osobeDropdown.appendChild(el);
	}
}

function ucitajDBZauzeca(podaci) {
	var zauzeca = pretvoriUZauzeca(podaci);
	Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
}

function pretvoriUZauzeca(niz) {
	var periodicna = [];
	var vanredna = [];
	for (var i = 0; i < niz.length; i++) {
		var z = {}; // zauzece
		var r = niz[i]; // rezervacija
		// postavljanje podataka
		z.pocetak = r.Termin.pocetak;
		z.kraj = r.Termin.kraj;
		z.naziv = r.Sala.naziv;
		z.predavac = r.Osoba.ime + " " + r.Osoba.prezime;
		if (r.Termin.redovni) {
			z.dan = r.Termin.dan;
			if (r.Termin.semestar == 0) {
				z.semestar = "zimski";
			} else if (r.Termin.semestar == 1) {
				z.semestar = "ljetni";
			}
			periodicna.push(z);
		} else {
			z.datum = r.Termin.datum;
			vanredna.push(z)
		}
	}
	return {"periodicna": periodicna, "vanredna": vanredna};
}

function dajPeriodicnuPosiljku() {
	var dayofweek = new Date(date.getFullYear(), trenutniMjesec, 1).getDay();
	// dayofweek je redni broj u sedmici prvog dana mjeseca, pocevsi od nule
	dayofweek = (dayofweek + 6) % 7;
	// danUSedmici je redni broj izabranog dana u sedmici, pocevsi od nule
	var danUSedmici = (odabraniDan + dayofweek - 1) % 7;
	// vraca se objekat koji sadrzi rezervaciju koju zahtjevamo i
	// tacan datum rezervacije potreban u slucaju greske
	var semestar;
	if (trenutniMjesec == 0 || trenutniMjesec > 8) {
		semestar = "zimski";
	} else if (trenutniMjesec > 0 && trenutniMjesec < 6) {
		semestar = "ljetni";
	} else {
		// Mjesec ne pripada nijednom semestru
		return false;
	}
	return {"rezervacija": {"dan": danUSedmici, "semestar": semestar, "pocetak": pocetak, "kraj": kraj, "naziv": sala, 
		"predavac": predavac},
		"datum": {"odabraniDan": odabraniDan, "mjesec" : trenutniMjesec, "godina" : godina}};
}

function izaberiDan(ev) {
	var idDana = ev.currentTarget.id;
	if (idDana.length === 5) {
		odabraniDan = Number(idDana.substring(4, 5));
	} else {
		odabraniDan = Number(idDana.substring(4, 6));
	}
	danConfirmProzor(ev);
}

function dajStringDatuma(d, m, y) {
	var d = new Date(y, m, d);
	var str = "";
	if (d.getDate() < 10) {
		str += "0" + d.getDate();
	} else {
		str += d.getDate();
	}
	str += ".";
	if (d.getMonth() + 1 < 10) {
		str += "0" + (d.getMonth() + 1);
	} else {
		str += d.getMonth() + 1;
	}
	return str + "." + d.getFullYear();
}

function danConfirmProzor(ev) {
	if (trenutniMjesec > 5 && trenutniMjesec < 9) {
		window.alert("Mjesec ne pripada nijednom semestru!");
		return;
	}
	if(window.confirm("Da li želite rezervisati ovaj termin?")) {
		var rez;
		if (periodicnost) {
			rez = dajPeriodicnuPosiljku();
			if (!rez) {
				// Ako mjesec ne pripada nijednom semestru periodicnu rezervaciju 
				// ne mozemo obaviti, prikazujemo poruku korisniku
				window.alert("Mjesec ne pripada nijednom semestru, ne moze se rezervisati periodicno!");
				return;
			}
		} else {
			rez = {"datum": dajStringDatuma(odabraniDan, trenutniMjesec, godina),"pocetak": pocetak, "kraj": kraj, "naziv": sala, 
				"predavac": predavac};
		}
		Pozivi.pokusajRezervisati(rez, periodicnost, ucitajDBZauzeca, Kalendar.obojiZauzeca, dodajEventListenereDanima, 
			document.getElementById("daniMjesec"), trenutniMjesec, sala, pocetak, kraj, window.alert);
	}
}

// event-handlers
{
	// odabir termina
	function dodajEventListenereDanima() {
		if (trenutniMjesec == null || sala == null || pocetak == null || kraj == null) {
			return;
		}
		var dani = document.getElementById("daniMjesec").childNodes;
		for (var i = 0; i < dani.length; i++) {
			// brisemo eventualni prijasnji listener
			dani[i].removeEventListener("click", izaberiDan);
			
			// ako je dan prazan ili ako je zauzet ne pridruzujemo listener
			if ((dani[i].className.indexOf("prazanDan") !== -1) || dani[i].querySelectorAll("div")[0].className.indexOf("zauzeta") !== -1) {
				continue;
			}
			dani[i].addEventListener("click", izaberiDan);
		}
		
	}
	dodajEventListenereDanima();
	
	
	var kRef = document.getElementById("daniMjesec");
	var salaDropdown = document.getElementById("salaDropdown");
	salaDropdown.addEventListener("change", function(ev) {
		sala = salaDropdown.value;
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
		dodajEventListenereDanima();
	});
	
	var kRef = document.getElementById("daniMjesec");
	var osobaDropdown = document.getElementById("osobaDropdown");
	osobaDropdown.addEventListener("change", function(ev) {
		predavac = osobaDropdown.value;
	});
	
	
	var pocetakInput = document.getElementById("pocetak");
	pocetakInput.addEventListener("input", function(ev) {
		pocetak = pocetakInput.value;
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
		dodajEventListenereDanima();
	});
	
	var krajInput = document.getElementById("kraj");
	krajInput.addEventListener("input", function(ev) {
		kraj = krajInput.value;
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
		dodajEventListenereDanima();
	});
	
	function promijeniMjesec(inc) {
		trenutniMjesec += inc;
		var m = document.getElementById("naslovMjeseca");
		m.innerHTML = mjeseci[trenutniMjesec];
		var mjesecSadrzaj = document.getElementById("daniMjesec");
		Kalendar.iscrtajKalendar(mjesecSadrzaj, trenutniMjesec);		
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
		dodajEventListenereDanima();
	}

	var prethodniButton = document.getElementById("prethodniButton");
	prethodniButton.addEventListener("click", function(ev) {
		sljedeciButton.disabled = false;		
		if (trenutniMjesec == 1) {
			// zabrani dugme ako je novi mjesec januar
			prethodniButton.disabled = true;
		}
		promijeniMjesec(-1);
	});

	var sljedeciButton = document.getElementById("sljedeciButton");
	sljedeciButton.addEventListener("click", function(ev) {
		prethodniButton.disabled = false;		
		if (trenutniMjesec == 10) {
			// zabrani dugme ako je novi mjesec decembar
			sljedeciButton.disabled = true;
		}
		promijeniMjesec(1);
	});

	var checkboxPeriodicna = document.getElementById("periodicna");
	checkboxPeriodicna.addEventListener("change", function (ev) {
		periodicnost = checkboxPeriodicna.checked;
	});
}
