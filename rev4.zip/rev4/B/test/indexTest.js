const supertest = require("supertest");
const assert = require('assert');
const app = require("../index");

describe("GET /osoblje", function(){
  it("Mora vratiti status 200", function(done) {
    supertest(app)
      .get("/osoblje")
      .expect(200)
      .end(function(err, res){
        if (err) done(err);
        done();
      });
  });
});

describe("GET /osoblje", function(){
  it("Mora vratiti text", function(done) {
    supertest(app)
      .get("/osoblje")
      .expect('Content-Type',/text/)
      .end(function(err, res){
        if (err) done(err);
        done();
      });
  });
});

describe("GET /rezervacijePodaci", function(){
  it("Mora vratiti text", function(done) {
    supertest(app)
      .get("/rezervacijePodaci")
      .expect('Content-Type',/json/)
      .end(function(err, res){
        if (err) done(err);
        done();
      });
  });
});

describe("GET /rezervacijePodaci", function(){
  it("Mora vratiti text", function(done) {
    supertest(app)
      .get("/rezervacijePodaci")
      .expect(200)
      .end(function(err, res){
        if (err) done(err);
        done();
      });
  });
});