function test1() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  Kalendar.ucitajPodatke(null, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test2() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ]

  Kalendar.ucitajPodatke(testPeriodicna, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test3() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 1,
          semestar: 'ljetni',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 1,
          semestar: 'ljetni',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ]

  Kalendar.ucitajPodatke(testPeriodicna, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test4() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testVanredna = [
      {
          datum: "1.12.2019",
          pocetak: "14:30",
          kraj: "15:50",
          naziv: "test",
          predavac: "test"            
      }
  ];

  Kalendar.ucitajPodatke(null, testVanredna);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test5() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 0,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      },
      {
          dan: 2,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      },
      {
          dan: 3,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      },
      {
          dan: 4,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      },
      {
          dan: 5,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      },
      {
          dan: 6,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ]

  Kalendar.ucitajPodatke(testPeriodicna, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test6() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ]

  Kalendar.ucitajPodatke(testPeriodicna, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test7() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 0,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 2,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ]

  Kalendar.ucitajPodatke(testPeriodicna, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
  
  testPeriodicna = [
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 4,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ]

  Kalendar.ucitajPodatke(testPeriodicna, null);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test8() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '17:00',
          kraj: '19:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ];

  var testVanredna = [
      {
          datum: "14.11.2019",
          pocetak: "14:30",
          kraj: "15:50",
          naziv: "test",
          predavac: "test"            
      }
  ];

  Kalendar.ucitajPodatke(testPeriodicna, testVanredna);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function test9() {
  var kalendar = document.getElementById('tabela-wrapper');
  kalendar.innerHTML = "";
  var trenutniMjesec = new Date().getMonth();

  var testPeriodicna = [
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '12:00',
          kraj: '14:00',
          naziv: 'Test 1',
          predavac: 'Test 1'
      },
      {
          dan: 1,
          semestar: 'zimski',
          pocetak: '17:00',
          kraj: '19:00',
          naziv: 'Test 2',
          predavac: 'Test 2'
      }
  ];

  var testVanredna = [
      {
          datum: "14.11.2019",
          pocetak: "14:30",
          kraj: "15:50",
          naziv: "test",
          predavac: "test"            
      },
      {
          datum: "15.11.2019",
          pocetak: "14:30",
          kraj: "15:50",
          naziv: "test",
          predavac: "test"            
      },
      {
          datum: "26.11.2019",
          pocetak: "14:30",
          kraj: "15:50",
          naziv: "test",
          predavac: "test"            
      },
      {
          datum: "2.11.2019",
          pocetak: "14:30",
          kraj: "15:50",
          naziv: "test",
          predavac: "test"            
      }
  ];

  Kalendar.ucitajPodatke(testPeriodicna, testVanredna);
  Kalendar.obojiZauzeca(kalendar, trenutniMjesec, 'VA', '12:00', '15:00');
}

function testKalendar1() {
  var kalendar = document.getElementById('tabela-wrapper');

  Kalendar.iscrtajKalendar(kalendar, 10);
}

function testKalendar2() {
  var kalendar = document.getElementById('tabela-wrapper');
  
  Kalendar.iscrtajKalendar(kalendar, 11);
}

function testKalendar3() {
  var trenutniMjesec = new Date().getMonth();
  var kalendar = document.getElementById('tabela-wrapper');

  Kalendar.iscrtajKalendar(kalendar, trenutniMjesec);
}

function testKalendar4() {
  var kalendar = document.getElementById('tabela-wrapper');

  Kalendar.iscrtajKalendar(kalendar, 0);
}

function testKalendar5() {
  var kalendar = document.getElementById('tabela-wrapper');

  Kalendar.iscrtajKalendar(kalendar, 5);

  document.getElementById('prethodni').click()
}

function testKalendar6() {
  var kalendar = document.getElementById('tabela-wrapper');

  Kalendar.iscrtajKalendar(kalendar, 5);

  document.getElementById('sljedeci').click()
}
