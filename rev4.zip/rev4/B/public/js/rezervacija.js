var trenutniMjesec = new Date().getMonth();
var kalendar = document.getElementById('tabela-wrapper');

Kalendar.iscrtajKalendar(kalendar, trenutniMjesec);

Pozivi.preuzmiRezervacije(kalendar, trenutniMjesec);

Pozivi.ucitajOsoblje();