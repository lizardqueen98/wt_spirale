var Pozivi = (function() {

//zadatak 3 iscrtavanje tabele

  function iscrtajOsobljeTabelu(niz){
    var tabela = '<table class="tabelaOsoblja"><tr><th colspan=4>Tabela osoblja</th></tr>';
    tabela += '<tr><th>Ime</th><th>Prezime</th><th>Uloga</th><th>Sala</th></tr>';
    //foreach za dobivene podatke iz baze
    niz.forEach((el)=>{
      tabela+='<tr><th>'+el.ime+'</th><th>'+el.prezime+'</th><th>'+el.uloga+'</th><th>'+el.sala+'</th></tr>';
    })
    tabela+='</table>';

    var htmlElemenat = document.querySelector('.sadrzaj');

    htmlElemenat.innerHTML = tabela;
  }

  //zadatak 3 

  function dohvatiZauzecaOsoblja(osobljeId) {
    return new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '/zauzeca?osobljeId=' + osobljeId);
        
        xhr.setRequestHeader("Content-Type", "application/json");            

        xhr.onload = function() {
            if (xhr.status === 200) {
                var data = JSON.parse(xhr.responseText);
                resolve(data);
            }
        };

        xhr.send();
    });
}



  //Zadatak 2


function dohvatiRezervacije() {
  return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();

      xhr.open('GET', '/rezervacijePodaci');

      xhr.onload = function() {
          if (xhr.status === 200) {
              var data = JSON.parse(xhr.responseText);
              resolve(data);
          }
      };

      xhr.send();
  });
}

  function dodajRezervaciju(sala, datum, pocetak, kraj, dan, semestar, periodicna, naziv, predavac) {
    return new Promise(function (resolve, reject) {
        var ajax = new XMLHttpRequest();
        ajax.open('POST', '/dodajRezervaciju');
        
        ajax.setRequestHeader("Content-Type", "application/json");            

        var data = {
            sala: sala,
            datum: datum,
            pocetak: pocetak,
            kraj: kraj,
            dan: dan,
            semestar,
            periodicna: periodicna,
            naziv: naziv,
            predavac: predavac
        }

        ajax.onload = function() {
            if (ajax.status === 200) {
                var data = JSON.parse(ajax.responseText);
                resolve(data);
            }
        };

        ajax.send(JSON.stringify(data));
    });
  }












// ---------------------

  function preuzmiRezervacije(kalendar, mjesec){
      var ajax = new XMLHttpRequest();
      ajax.open("GET","/ucitaj_rezervacije");
      ajax.onload = function(){
          if(ajax.status === 200 && ajax.readyState === 4){
            var podaci = JSON.parse(ajax.responseText);
            
            Kalendar.ucitajPodatke(podaci.periodicna, podaci.vanredna);
            Kalendar.obojiZauzeca(kalendar, mjesec, 'VA', '12:00', '14:00');
          }
      }
      ajax.send();
  }

  function kreirajSlike (niz) {
    niz.forEach((link) => {
        var div = document.createElement("DIV");
        div.setAttribute('class', 'gridItem');
        var img = document.createElement("IMG");
        img.setAttribute('src', link);
        document.getElementsByClassName("sadrzaj")[0].appendChild(div).appendChild(img);
    });
  }


  //zadatak 1 ajax
  function ucitajOsoblje(){
    var forma = document.getElementsByTagName("form")[0];
    var ajax = new XMLHttpRequest();
    ajax.open("GET","/osoblje");
    ajax.onload = function(){
        if(ajax.status === 200 && ajax.readyState === 4){
          var redovi = JSON.parse(ajax.responseText)
          var select = '<span>Osoblje:</span><select>';
          redovi.forEach((el)=>{
            select += '<option value="'+el.uloga+'">'+el.ime+' '+el.prezime+','+el.uloga+'</option>';
          })
          select+='</select>';
          var dodatnoPolje = document.createElement("DIV");
          dodatnoPolje.setAttribute('class', 'formElement');
          dodatnoPolje.innerHTML=select;
          forma.appendChild(dodatnoPolje);
        }
    }
    ajax.send();
  }
  
  function ucitajSlike(event,stranica){

    var ajax = new XMLHttpRequest();
    ajax.open("GET","/promjeni_slike?action="+event+"&page="+stranica);
    ajax.onload = function(){
        if(ajax.status === 200 && ajax.readyState === 4){
          var rezultati = JSON.parse(ajax.responseText);
          console.log(rezultati.imaSljedecih);
          if (rezultati.imaSljedecih!=true){
            document.getElementsByClassName("sadrzaj")[0].innerHTML = "";
            kreirajSlike(rezultati.slike);
            var buttonContainer = "";
            buttonContainer = document.createElement("DIV");
            buttonContainer.setAttribute('class', 'buttonContainer');
            var prethodniBtn = document.createElement("BUTTON");
            prethodniBtn.innerHTML = "Prethodni";
            prethodniBtn.addEventListener('click', klikPrethodni);
            buttonContainer.appendChild(prethodniBtn);
            document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);
          }
          else if (stranica == 0 && event == "prethodni"){
            document.getElementsByClassName("sadrzaj")[0].innerHTML = "";
            kreirajSlike(rezultati.slike);
            var buttonContainer = "";
            buttonContainer = document.createElement("DIV");
            buttonContainer.setAttribute('class', 'buttonContainer');
            var slijedeciBtn = document.createElement("BUTTON");
            slijedeciBtn.innerHTML = "Slijedeci";
            slijedeciBtn.addEventListener('click', klikSlijedeci);
            buttonContainer.appendChild(slijedeciBtn);
            document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);
          }
          else {
            document.getElementsByClassName("sadrzaj")[0].innerHTML = "";
            kreirajSlike(rezultati.slike);
            var buttonContainer = "";
            buttonContainer = document.createElement("DIV");
            buttonContainer.setAttribute('class', 'buttonContainer');
            var prethodniBtn = document.createElement("BUTTON");
            prethodniBtn.innerHTML = "Prethodni";
            prethodniBtn.addEventListener('click', klikPrethodni);
            buttonContainer.appendChild(prethodniBtn);
            var slijedeciBtn = document.createElement("BUTTON");
            slijedeciBtn.innerHTML = "Slijedeci";
            slijedeciBtn.addEventListener('click', klikSlijedeci);
            buttonContainer.appendChild(slijedeciBtn);
            document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);
          }
        }
    }
    ajax.send();

  }
  return {
      preuzmiRezervacije: preuzmiRezervacije,
      ucitajSlike: ucitajSlike,
      ucitajOsoblje: ucitajOsoblje,
      dohvatiZauzecaOsoblja: dohvatiZauzecaOsoblja,
      dodajRezervaciju: dodajRezervaciju,
      dohvatiRezervacije: dohvatiRezervacije
  }
}());
  