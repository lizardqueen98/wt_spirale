var sadrzaj = document.getElementsByClassName("sadrzaj")[0];

