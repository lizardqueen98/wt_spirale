document.getElementsByClassName("sadrzaj")[0].innerHTML = "";

Pozivi.ucitajSlike("", 0);

// var prethodniBtn = document.createElement("BUTTON");
// var slijedeciBtn = document.createElement("BUTTON");
// prethodniBtn.innerHTML = "Prethodni";
// slijedeciBtn.innerHTML = "Slijedeci";
// prethodniBtn.addEventListener('click', klikPrethodni);
// slijedeciBtn.addEventListener('click', klikSlijedeci);


// var div1 = document.createElement("DIV");
// var div2 = document.createElement("DIV");
// var div3 = document.createElement("DIV");
// div1.setAttribute('class', 'gridItem');
// div2.setAttribute('class', 'gridItem');
// div3.setAttribute('class', 'gridItem');

// var img1 = document.createElement("IMG");
// var img2 = document.createElement("IMG");
// var img3 = document.createElement("IMG");
// img1.setAttribute('src', '/img/1.jpg');
// img2.setAttribute('src', '/img/2.jpg');
// img3.setAttribute('src', '/img/3.jpg');

// document.getElementsByClassName("sadrzaj")[0].appendChild(div1).appendChild(img1);
// document.getElementsByClassName("sadrzaj")[0].appendChild(div2).appendChild(img2);
// document.getElementsByClassName("sadrzaj")[0].appendChild(div3).appendChild(img3);

// var buttonContainer = document.createElement("DIV");
// buttonContainer.appendChild(prethodniBtn);
// buttonContainer.appendChild(slijedeciBtn);
// buttonContainer.setAttribute('class', 'buttonContainer');
// document.getElementsByClassName("sadrzaj")[0].appendChild(buttonContainer);

var trenutnaStranica = 0;
var imaSljedecih = true;

function klikPrethodni() {
  if (trenutnaStranica == 0)
    return;

  trenutnaStranica--;
  Pozivi.ucitajSlike("prethodni",trenutnaStranica);
}

function klikSlijedeci() {  
  if(!imaSljedecih)
    return;
  
  trenutnaStranica++;
  Pozivi.ucitajSlike("slijedeci",trenutnaStranica);
}