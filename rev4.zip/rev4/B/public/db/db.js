const Sequelize = require("sequelize");
const sequelize = new Sequelize("dbwt19","root","root",{
  host:"127.0.0.1",
  dialect:"mysql",
  logging:false
});

const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname+'/Osoblje.js');
db.rezervacija = sequelize.import(__dirname+'/Rezervacija.js');
db.termin = sequelize.import(__dirname+'/Termin.js');
db.sala = sequelize.import(__dirname+'/Sala.js');

//relacije
// Veza 1-n
db.osoblje.hasMany(db.rezervacija,{as:'rezervacijeOsoblje', foreignKey:'osoba'});

// 1-1
db.termin.hasOne(db.rezervacija,{as:'rezervacijeTermin',foreignKey:'termin'});

// 1-n odnosno više na 1 kako je napisano u spirali
db.sala.hasMany(db.rezervacija,{as:'rezervacijeSale', foreignKey:'sala'});

// 1-1
db.osoblje.hasOne(db.sala,{as:'saleOsobe',foreignKey:'zaduzenaOsoba'});

module.exports=db;