const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
var fs = require("fs");

var app = express();

app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//baza
const db = require('./public/db/db.js');

function errLog(err){
  console.log("Error:",err);
}

db.sequelize
  .authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });

//ubacivanje redova 
db.sequelize.sync({force:true}).then(()=>{
  
  db.osoblje.bulkCreate([{ime:"Neko",prezime:"Nekić",uloga:"Profesor"},
                          {ime:"Drugi",prezime:"Neko",uloga:"Asistent"},
                          {ime:"Test",prezime:"Test",uloga:"Asistent"},])
                          .catch(errLog);

  db.sala.bulkCreate([{naziv:"1-11",zaduzenaOsoba:1},
                      {naziv:"1-15",zaduzenaOsoba:2}])
                      .catch(errLog);

  db.termin.bulkCreate([{redovni:false,dan:null,datum:"01.01.2020",semestar:null,pocetak:"12:00",kraj:"13:00"},
                        {redovni:true,dan:0,datum:null,semestar:"zimski",pocetak:"13:00",kraj:"14:00"}])
                        .catch(errLog);

  db.rezervacija.bulkCreate([{termin:1,sala:1,osoba:1},
                            {termin:2,sala:1,osoba:3}])
                            .catch(errLog);
});

var slike = ["http://images.unsplash.com/reserve/bOvf94dPRxWu0u3QsPjF_tree.jpg?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjEyMDd9",
          "http://images.unsplash.com/reserve/bOvf94dPRxWu0u3QsPjF_tree.jpg?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjEyMDd9",
          "https://images.unsplash.com/photo-1500622944204-b135684e99fd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1442850473887-0fb77cd0b337?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1433086966358-54859d0ed716?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1577180234245-9d43488a6722?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjExMDk0fQ&w=1000&q=80",
          "https://images.unsplash.com/photo-1441239372925-ac0b51c4c250?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1433086966358-54859d0ed716?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
          "https://images.unsplash.com/photo-1542662565-7e4b66bae529?ixlib=rb-1.2.1&auto=format&fit=crop&w=428&h=214&q=60",
          "https://images.unsplash.com/photo-1500622944204-b135684e99fd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80"];


app.get("/ucitaj_rezervacije", (req,res) => {
  fs.readFile("zauzeca.json", (err,data) => {
    if (err) throw err;
    var zaduzenja = JSON.parse(data);
    res.json(zaduzenja);
  });
});

app.get("/promjeni_slike", (req,res) => {
  var stranica = parseInt(req.query.page);

  var brojStranica = Math.ceil(slike.length/3);

  var response = {
    imaSljedecih: true,
    slike: []
  }

  if(stranica == brojStranica - 1)
    response.imaSljedecih = false;

  var pocetak = stranica * 3;
  var kraj = (stranica + 1) * 3 > slike.length ? slike.length : (stranica + 1) * 3;

  response.slike = slike.slice(pocetak, kraj);

  res.json(response);
});


app.get("/", (req,res)=>{
  res.sendFile("pocetna.html" , { root: (path.join(__dirname + "\\public")) })
});

app.get("/unos",(req,res)=>{
  res.sendFile("unos.html" , { root: (path.join(__dirname + "\\public")) });
})

app.get("/pocetna",(req,res)=>{
  res.sendFile("pocetna.html" , { root: (path.join(__dirname + "\\public")) });
})

app.get("/rezervacija",(req,res)=>{
  res.sendFile("rezervacija.html" , { root: (path.join(__dirname + "\\public")) });
})

app.get("/sale",(req,res)=>{
  res.sendFile("sale.html" , { root: (path.join(__dirname + "\\public")) });
})



//Zadatak 1
app.get("/osoblje",(req,res)=>{
  const osoblje = db.osoblje.findAll()
    .catch((err)=>console.log(err))
    .then((osoblje)=>res.send(JSON.stringify(osoblje)));
});


//Zadatak 2

app.get('/rezervacijePodaci', function(req, res){
  db.rezervacija.findAll().then(function(rezervacije){
      res.json(rezervacije);
      res.end();
  }).catch(function(err) {
      res.json(null);
      res.end();
  });
});

app.post('/dodajRezervaciju', function(req, res){
  var data = req.body;
  
  var rezervacija = {
      redovni: data.periodicno,
      dan: data.dan,
      datum: data.datum,
      semestar: data.semestar,
      pocetak: data.pocetak,
      kraj: data.kraj,
      termin: data.termin,
      osoba: data.osoba
  };
  
  var response = {
      succeeded: true,
      message: 'Rezervacija dodata'
  }

  db.termin.create({
      redovni: data.periodicno,
      dan: data.dan,
      datum: data.datum,
      semestar: data.semestar,
      pocetak: data.pocetak,
      kraj: data.kraj,
      termin: data.termin,
      osoba: data.osoba
  }).then(function(){
      res.json(response);
      res.end();

      return;
  }).catch(function(error){
      response.succeeded = false;
      response.message = 'Greska';

      res.json(response);
      res.end();

      return;
  });
});





//zadatak 3 osoblje postoji pa je preimenovan pristup page-u na osoblje_page

app.get("/osoblje_page",(req,res)=>{
  res.sendFile("osoblje.html" , { root: (path.join(__dirname + "\\public")) });
})


//zadatak 3

app.get('/zauzeca', function(req, res){
  var osobljeId = parseInt(req.query.osobljeId);

  db.osoblje.findOne({
      where: {
          id: osobljeId,
      }
  }).then(function(osoblje) {
      db.rezervacija.findAll({
          where: {
              osoba: osoblje.dataValues.id,
          }
      }).then(function(rezervacije) {
          var ids = rezervacije.map(x => x.dataValues.id);

          db.termini.findAll({
              where: {
                  termin: {
                      [Op.in]: ids
                    }
              }
          }).then(function(termini) {
              var trenutniDatum = new Date();
              var salaId = -1;

              termini.forEach(function(element) {
                  if(element.dataValues.redovni) {
                      if(element.dataValues.dan == trenutniDatum.getDay()) {
                          var pocetakSat = element.dataValues.pocetak.substring(0, element.dataValues.pocetak.indexOf(':'));
                          var pocetakMinute = element.dataValues.pocetak.substring(element.dataValues.pocetak.indexOf(':') + 1, element.dataValues.pocetak.length);
                          var krajSat = element.dataValues.kraj.substring(0, element.dataValues.kraj.indexOf(':'));
                          var krajMinute = element.dataValues.kraj.substring(element.dataValues.kraj.indexOf(':') + 1, element.dataValues.kraj.length);

                          var pocetak = new Date(trenutniDatum.getFullYear(), trenutniDatum.getMonth(), trenutniDatum.getDate(), pocetakSat, pocetakMinute, '00');
                          var kraj = new Date(trenutniDatum.getFullYear(), trenutniDatum.getMonth(), trenutniDatum.getDate(), krajSat, krajMinute, '00');

                          if(pocetak >= trenutniDatum && trenutniDatum <= kraj)
                              salaId = element.dataValues.id;
                      }
                  }
                  else {
                      var firstIndex = element.dataValues.datum.indexOf('.');
                      var secondIndex = element.dataValues.datum.indexOf('.', firstIndex + 1);

                      var dan = element.dataValues.datum.substr(0, firstIndex);
                      var mjesec = element.dataValues.datum.substr(firstIndex + 1, secondIndex);
                      var godina = element.dataValues.datum.substr(secondIndex + 1, element.dataValues.datum.length);

                      var pocetakSat = element.dataValues.pocetak.substring(0, element.dataValues.pocetak.indexOf(':'));
                      var pocetakMinute = element.dataValues.pocetak.substring(element.dataValues.pocetak.indexOf(':') + 1, element.dataValues.pocetak.length);
                      var krajSat = element.dataValues.kraj.substring(0, element.dataValues.kraj.indexOf(':'));
                      var krajMinute = element.dataValues.kraj.substring(element.dataValues.kraj.indexOf(':') + 1, element.dataValues.kraj.length);

                      var pocetak = new Date(godina, parseInt(mjesec) - 1, dan, pocetakSat, pocetakMinute, '00');
                      var kraj = new Date(godina, parseInt(mjesec) - 1, dan, krajSat, krajMinute, '00');

                      if(pocetak >= trenutniDatum && trenutniDatum <= kraj)
                          salaId = element.dataValues.id;
                  }
              });

              if(salaId != -1) {
                  db.sala.findOne({
                      where: {
                          id: salaId,
                      }
                  }).then(function(sala) {
                      res.json(sala.dataValues.naziv);
                      res.end();

                      return;
                  }).catch(function(error){
                      res.json(null);
                      res.end();
      
                      return;
                  });
              }
              else {
                  res.json(null);
                  res.end();
              }

              return;
          }).catch(function(error){
              res.json(null);
              res.end();

              return;
          });
      }).catch(function(error){
          res.json(null);
          res.end();

          return;
      });
  }).catch(function(error){
      res.json(null);
      res.end();

      return;
  });
});



app.listen(8080, ()=>{console.log("Server running!");})


//za testove
module.exports = app;