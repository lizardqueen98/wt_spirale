window.onload = function () {
	Pozivi.ucitajOsobe();
};