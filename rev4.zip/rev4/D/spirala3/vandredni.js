var vanredni = [
    {
        datum: "12.12.2019",
        pocetak: "14:00",
        kraj: "16:00",
        naziv: "0-02",
        predavac: "Neko"
    },
    {
        datum: "23.11.2019",
        pocetak: "10:00",
        kraj: "12:00",
        naziv: "0-01",
        predavac: "Neko"
    },
    {
        datum: "12.12.2019",
        pocetak: "15:00",
        kraj: "16:00",
        naziv: "V2",
        predavac: "Neko"
    },
    {
        datum: "31.3.2019",
        pocetak: "12:00",
        kraj: "16:00",
        naziv: "0-01",
        predavac: "Neko"
    },
    {
        datum: "10.11.2019",
        pocetak: "14:00",
        kraj: "16:00",
        naziv: "VA1",
        predavac: "Neko"
    },
    {
        datum: "10.11.2019",
        pocetak: "14:00",
        kraj: "16:00",
        naziv: "VA2",
        predavac: "Neko"    
    },
    {
        datum: "1.5.2019",
        pocetak: "14:00",
        kraj: "16:00",
        naziv: "0-01",
        predavac: "Neko"
    },
    {
        datum: "8.2.2019",
        pocetak: "14:00",
        kraj: "16:00",
        naziv: "0-02",
        predavac: "Neko"
    }
];