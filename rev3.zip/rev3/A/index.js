const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/',(request, response)=>{
    response.redirect('/pocetna.html');
});

app.post('/zauzeca', (req, res)=>{
    fs.readFile(__dirname+"/zauzeca.json", "utf8", function(err, data){
        if(err) throw err;
        var result = JSON.parse(data);
        if (!req.body.tip){
            res.json(result);
        }else{
            res.json(result[req.body.tip]);
        }
    });
});

app.post('/slike',(req,res) => {
    fs.readdir(__dirname+'/public/img', (err, files) => {
        const index = req.body.lastIndex;
        let result = [];
        for(let i = 0; i<files.length; i+=3){
            myChunk = files.slice(i,i+3);
            result.push(myChunk);
        }
        res.json({images:result[index],size:result.length});
      });
});

app.post('/zauzece',(req,res)=>{
    fs.readFile(__dirname+"/zauzeca.json","utf8", (err,data)=>{
        if(err) throw err;
        var result = JSON.parse(data);
        let zauzece = req.body;
        let zauzeca = [];
        let periodicno={};
        let vanredno={};
        if (zauzece.periodicno){
            if (zauzece.mjesec == 0 || zauzece.mjesec > 8){
                periodicno.semestar = 'zimski';
            }else if (zauzece.mjesec > 0 && zauzece.mjesec < 6 ){
                periodicno.semestar = 'ljetni';
            }else{
                res.json({message:'Error'});
            }
            periodicno.naziv = zauzece.sala;
            periodicno.predavac = 'Neko';
            periodicno.pocetak = zauzece.pocetak;
            periodicno.kraj = zauzece.kraj;
            periodicno.dan = new Date(new Date().getFullYear(),zauzece.mjesec,zauzece.datum).getDay()-1;
            if (periodicno.dan < 0)periodicno.dan = 6;
            zauzeca = [... convertPeriodicnoToVanredna(periodicno)];
        }else{
            vanredno = {
                datum:`${zauzece.datum}.${zauzece.mjesec+1}.${new Date().getFullYear()}`,
                pocetak:zauzece.pocetak,
                kraj:zauzece.kraj,
                naziv:zauzece.sala,
                predavac:"Neko"
            }
            zauzeca.push(
                vanredno
            );
        }
        test_periodicna = result.periodicna;
        test_vanredna = result.vanredna;
        test_periodicna.forEach(element => {
            let converted = convertPeriodicnoToVanredna(element);
            test_vanredna = [...test_vanredna,...converted];
        });
        let wrong = false;
        zauzeca.forEach(zauzece => {
            if( jeLiZauzeto(zauzece.naziv,new Number(zauzece.datum.split('.')[1]),zauzece.pocetak,zauzece.kraj,new Number(zauzece.datum.split('.')[0]),test_vanredna)){
                wrong = true;
            }
        })
        if(wrong){
            res.json({message:"Something"});
        }else{
            if(zauzece.periodicno){
                result.periodicna.push(periodicno);
            }else{
                result.vanredna.push(vanredno);
            }
            fs.writeFile(__dirname+'/zauzeca.json',JSON.stringify(result,null,'\t'),(err)=>{
                if(err)throw err;
                console.log("Saved");
                res.json(result);
            });

        }
    });
});

function convertPeriodicnoToVanredna(periodicno){
    let zauzeca = [];
    if(periodicno.semestar === 'zimski'){
        for(let mjesec = 9; mjesec<12; mjesec++){
            zauzeca.push(...makeZauzeca(mjesec, periodicno));
        }
        //ovdje treba i za januar
        zauzeca.push(...makeZauzeca(0,periodicno));
    }else if(periodicno.semestar === 'ljetni'){
        for(let mjesec = 1; mjesec<6; mjesec++){
            zauzeca.push(...makeZauzeca(mjesec,periodicno));
        }
    }
    return zauzeca;
}

function makeZauzeca(mjesec,zauzece){
    const godina = new Date().getFullYear();
    const broj_dana = new Date(godina, mjesec+1,0).getDate();
    zauzeca = [];
    for(let i = 1; i<=broj_dana; i++){
        let dan = new Date(godina, mjesec,i).getDay() - 1;
        if (dan < 0)dan = 6;
        if (dan == zauzece.dan){
            zauzeca.push({
                datum:`${i}.${mjesec+1}.${godina}`,
                pocetak:zauzece.pocetak,
                kraj:zauzece.kraj,
                naziv:zauzece.naziv,
                predavac:zauzece.predavac
            })
        }
    }
    return zauzeca;
}


function jeLiZauzeto(sala,mjesec,pocetak,kraj,datum,zauzeca){
    let trenutnaZauzeca = zauzeca.filter(zauzece => {
        const a = zauzece.datum.split('.')[1];
        const b = mjesec+"";
        return a==b && sala == zauzece.naziv;
    });
    
    trenutnaZauzeca = trenutnaZauzeca.filter(zauzece => {
        const [refPocetakH,refPocetakM] = pocetak.split(':').map(broj => new Number(broj));
        const [refKrajH,refKrajM] = kraj.split(':').map(broj => new Number(broj));
        const [PocetakH,PocetakM] = zauzece.pocetak.split(':').map(broj => new Number(broj));
        const [KrajH,KrajM] = zauzece.kraj.split(':').map(broj => new Number(broj));
        const refPocetak = refPocetakH+refPocetakM/60.00;
        const Pocetak = PocetakH+PocetakM/60.00;
        const refKraj = refKrajH+refKrajM/60.00;
        const Kraj = KrajH+KrajM/60.00;
        return !(Pocetak >= refKraj || Kraj <= refPocetak);
    });
    
    const occupation = trenutnaZauzeca.filter(zauzece => {
        const [day,,] = zauzece.datum.split('.');
        return day == datum;
    });
    if(occupation.length === 0){
        return false;
    }else{
        return true;
    }
}


app.listen(8080);