let Pozivi = (function(){
    'use strict';
    function getZauzeca(callback){
        let req = new XMLHttpRequest();
        req.open('POST','/zauzeca',true);
        req.send(JSON.stringify({}));
        req.onload = ev => {
            const zauzeca = JSON.parse(req.response);
            callback(zauzeca["periodicna"],zauzeca["vanredna"]);
        };
    }
    function rezervisi(ref,sala,mjesec,pocetak,kraj,datum,periodicno){
        const body = {
            sala:sala,
            mjesec:mjesec,
            pocetak:pocetak,
            kraj:kraj,
            datum:datum,
            periodicno:periodicno
        };
        let req = new XMLHttpRequest();
        req.open('POST','/zauzece',true);
        req.setRequestHeader("Content-Type","application/json");
        req.send(JSON.stringify(body));
        req.onload = ev => {
            const zauzeca = JSON.parse(req.response);
            if(zauzeca.message){
                alert("Nije moguce rezervisati "+sala+" za navedeni datum "+datum+"/"+(mjesec+1)+"/"+new Date().getFullYear()+" i termin od "+pocetak+" do "+kraj+"!" );
            }else{
                Kalendar.ucitajPodatke(zauzeca["periodicna"],zauzeca["vanredna"]);
                Kalendar.obojiZauzeca(ref,mjesec,sala,pocetak,kraj);
            }
        };
    }
    function getNext(lastIndex,callback){
        let ajax = new XMLHttpRequest();
        ajax.open("POST","/slike");
        ajax.setRequestHeader("Content-Type","application/json" );
        ajax.send(JSON.stringify({
            lastIndex:lastIndex
        }));
        ajax.onload = () =>{
            const response = JSON.parse(ajax.response);
            callback(response.images,response.size);
        } ;
    }
    return {
        getZauzeca,
        rezervisi,
        getNext
    }
}());