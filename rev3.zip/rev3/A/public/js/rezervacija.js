
let mjesec;
let ref;
let inputData = {

};

window.onload = () => {
    mjesec = new Date().getMonth();
    monthRegulation();
    ref = document.getElementById("kalendar");
    const inputNames = ['sala','pocetak','kraj','periodicna'];
    inputNames.forEach(name => {
        document.getElementsByName(name)[0].addEventListener('change', (event) => {
            inputChangeHandler(event,name);
        })
        inputChangeHandler(null,name);     
    });
    Kalendar.iscrtajKalendar(ref,mjesec);
    Pozivi.getZauzeca((redovnaM,vanrednaM)=>{
        Kalendar.ucitajPodatke(redovnaM,vanrednaM);
        Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
    });
}

const inputChangeHandler = (event, name) => {
    inputData[name] = (name==='periodicna')?document.getElementsByName(name)[0].checked:document.getElementsByName(name)[0].value;
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}

const monthRegulation = () => {
    if(mjesec > 10){
        document.getElementById("sljedeci").disabled = true;
    }else if(mjesec < 1){
        document.getElementById("prethodni").disabled = true;
    }else{
        document.getElementById("prethodni").disabled = false;
        document.getElementById("sljedeci").disabled = false;
    }
}

const sljedeci = () => {
    mjesec++;
    monthRegulation();
    Kalendar.iscrtajKalendar(document.getElementById('kalendar'),mjesec);
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}

const prethodni = () =>{
    mjesec--;
    monthRegulation();
    Kalendar.iscrtajKalendar(document.getElementById('kalendar'),mjesec);
    Kalendar.obojiZauzeca(ref,mjesec,inputData.sala, inputData.pocetak, inputData.kraj);
}



window.onresize = () => {
    //console.log(window.innerWidth);
}


const rezervisi = (elem) => {
    if(Kalendar.jeLiZauzeto(inputData["sala"],mjesec,inputData.pocetak,inputData.kraj,elem.getElementsByClassName("cell-content")[0].innerHTML)){
        alert("Nije moguce rezervisati "+inputData.sala+" za navedeni datum "+elem.getElementsByClassName("cell-content")[0].innerHTML+"/"+(mjesec+1)+"/"+new Date().getFullYear()+" i termin od "+inputData.pocetak+" do "+inputData.kraj+"!" );
    }else{
        if(confirm("Želite li izvršiti rezervaciju?")){
            Pozivi.rezervisi(ref,inputData["sala"],mjesec,inputData.pocetak,inputData.kraj,elem.getElementsByClassName("cell-content")[0].innerHTML,inputData.periodicna);

        }else{
            console.log("Kanselujem...");
        }
    }
    
}