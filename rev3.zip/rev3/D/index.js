const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/public"));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/pocetna.html');
});

app.post('/pocetna.html', (req, res) => {

    let triSlike = [];
    let ucitaneSlike = req.body;

    const testFolder = '/public/slike/';
    const fs = require('fs');

    fs.readdir(__dirname + '/public/slike/', (err, files) => {
        for (let i = 0; i < files.length; i++) {
            if (!daLiSadrzi(ucitaneSlike, files[i])) {
                triSlike.push(files[i]);
                if (triSlike.length == 3) break;
            }
        }
        res.json({ triSlike });
    });  
});

function daLiSadrzi(lista, element) {
    for (var i = 0; i < lista.length; i++) {
        if (lista[i] === element) {
            return true;
        }
    }
    return false;
}

app.get('/zauzeca.json', (req, res) => {
    res.sendFile(__dirname + '/zauzeca.json');
});

app.post('/', (req, res) => {
    let tijelo = req.body;
    let novaLinija = JSON.stringify(tijelo);

    fs.readFile("zauzeca.json", (err, dataBuffer) => {

        if (err) throw err;
        var data = dataBuffer.toString('utf-8');
        let jsonData = JSON.parse(data);
        var logicka = 1;
 
        var parse_obj = JSON.parse(data);
        if (tijelo.hasOwnProperty("dan")) {
            for (let i = 0; i < jsonData.periodicna.length; i++) {
                let jednoZauzece = jsonData.periodicna[i];
                if (jednoZauzece.dan == tijelo.dan && ((tijelo.pocetak <= jednoZauzece.pocetak && tijelo.kraj > jednoZauzece.pocetak) || (tijelo.pocetak == jednoZauzece.pocetak && tijelo.kraj == jednoZauzece.kraj)
                    || (tijelo.pocetak < jednoZauzece.kraj && tijelo.kraj >= jednoZauzece.kraj)) && jednoZauzece.semestar == tijelo.semestar && jednoZauzece.naziv ==tijelo.naziv) logicka = 0;
            }

            for (let i = 0; i < jsonData.vanredna.length; i++) {
                let jednoZauzece = jsonData.vanredna[i];
                var strnigDatum = (jednoZauzece.datum).split(".");
                strnigDatum.reverse();
                strnigDatum.join("-");
               
            
                let datum = new Date(strnigDatum);
               

                if (datum.getDay()== tijelo.dan && ((tijelo.pocetak <= jednoZauzece.pocetak && tijelo.kraj > jednoZauzece.pocetak) || (tijelo.pocetak == jednoZauzece.pocetak && tijelo.kraj == jednoZauzece.kraj)
                    || (tijelo.pocetak < jednoZauzece.kraj && tijelo.kraj >= jednoZauzece.kraj)) && jednoZauzece.naziv==tijelo.naziv && dajSemestar(datum.getMonth())==tijelo.semestar) logicka = 0;

                    
            }

            if (logicka) {
                noviPer = {
                    dan: tijelo.dan,
                    semestar: tijelo.semestar,
                    pocetak: tijelo.pocetak,
                    kraj: tijelo.kraj,
                    naziv: tijelo.naziv,
                    predavac: tijelo.predavac
                }

                parse_obj['periodicna'].push(noviPer);
            }

        }
        else {

            for (let i = 0; i < jsonData.periodicna.length; i++) {
                let jednoZauzece = jsonData.periodicna[i];
                var strnigDatum = (tijelo.datum).split(".");
                strnigDatum.reverse();
                strnigDatum.join("-");
                let datum = new Date(strnigDatum);
                
                if (datum.getDay()== jednoZauzece.dan && ((tijelo.pocetak <= jednoZauzece.pocetak && tijelo.kraj > jednoZauzece.pocetak) || (tijelo.pocetak == jednoZauzece.pocetak && tijelo.kraj == jednoZauzece.kraj)
                    || (tijelo.pocetak < jednoZauzece.kraj && tijelo.kraj >= jednoZauzece.kraj)) && jednoZauzece.naziv==tijelo.naziv && dajSemestar(datum.getMonth())==jednoZauzece.semestar) logicka = 0;
                
            }

            for (var i = 0; i < jsonData.vanredna.length; i++) {
                var jednoZauzece = jsonData.vanredna[i];
                if (jednoZauzece.datum == tijelo.datum && ((tijelo.pocetak <= jednoZauzece.pocetak && tijelo.kraj > jednoZauzece.pocetak) || (tijelo.pocetak == jednoZauzece.pocetak && tijelo.kraj == jednoZauzece.kraj)
                    || (tijelo.pocetak < jednoZauzece.kraj && tijelo.kraj >= jednoZauzece.kraj)) && jednoZauzece.naziv == tijelo.naziv) logicka = 0;
                    
            }
            if (logicka)
                parse_obj['vanredna'].push(tijelo);
        }
        if (logicka) {
            Str_txt = JSON.stringify(parse_obj);


            fs.writeFile('zauzeca.json', Str_txt, function () {
                novi = {"Poruka" : "", "Objekt" : parse_obj};
                novi = JSON.stringify(novi);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(novi);
                res.end();
            })
        } else {
            let s = "Nije moguće rezervisati salu " + tijelo.naziv + " za navedeni datum " + tijelo.datum + " i termin od " + tijelo.pocetak + " do " + tijelo.kraj + "!";
            novi = {"Poruka" : s, "Objekt" : parse_obj};
            novi = JSON.stringify(novi);
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(novi);
            res.end();
        }



    });

});
app.listen(8080);

function dajSemestar(mjesec){
    ljetni = [1,2,3,4,5];
    zimski = [9,10,11,0];

    if(ljetni.includes(mjesec)) return "ljetni";
    else if(zimski.includes(mjesec)) return "zimski";
    else return "raspust";
}