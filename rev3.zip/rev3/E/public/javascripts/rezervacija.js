var poziv;

function ucitajPod () {
  
  poziv = Pozivi;
  poziv.ucitajPodatke1();
  Kalendar.iscrtajKalendar(document.getElementById('kalendar'), 11);
}
