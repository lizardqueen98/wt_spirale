/* implementacije funkcija, ajax */
let Pozivi = (function () {

  function ucitajZauzeca () {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function () {
      if (ajax.readyState == 4 && ajax.status == 200) {
        var zauzecaPodaci = JSON.parse(ajax.responseText);
        
        var periodicnaZauzeca1 = zauzecaPodaci.periodicno;
        var vanrednaZauzeca1 = zauzecaPodaci.vanredno;
        Kalendar.ucitajPodatke(periodicnaZauzeca1, vanrednaZauzeca1);
      }
      if (ajax.readyState == 4 && ajax.status == 404) {
        console.log('Greska!');
      }
    };
    ajax.open('GET', '/zauzeca.json', true);
    ajax.send();
  }
/**
   *
   * @param type - GET, POST, FETCH, DELETE
   * @param uri - full endpoint
   * @param headers - object
   * @param data - body or payload
   * @returns {Promise<unknown>} - Resolves in callback of APIs
   */
  async function serviceRequest (type, uri, headers, data, raw) {
    const settings = {
      url: uri,
      type: type,
      headers: headers
    };
    return new Promise(function (resolve, reject) {
    
      let http = new XMLHttpRequest();
      http.open(settings.type, settings.url, true);

      
      if (!!headers) {
        Object.keys(headers).forEach((header) => {
          http.setRequestHeader(header.name, header.value);
        });
      }
      http.send(!!data ? data : null);
      http.onreadystatechange = function () {
        if (http.readyState === 4) {
          if (http.status === 200) {
            resolve(raw !== undefined ? http.response : JSON.parse(http.response));
          } else {
            reject(`Error:: ${http.status} @ ${http.responseURL}`);
          }
        }
      };
    });
  }

  const provider = "/slike";
  const headers = [
    {
      name: 'Content-Type',
      value: 'application/json'
    }
  ];



  async function slike (page, records_per_page) {

    const provider =  "/slike/" + page + '/' + records_per_page;

    const headers = [
      {
        name: 'Content-Type',
        value: 'application/json'
      }
    ];
    let image;

    let slike;


    try {
      slike = await serviceRequest('GET', provider, headers);

      return slike;
    } catch (error) {
      console.error(error);
    }
  }

  var objJson = []
  var current_page = 1;
  var records_per_page = 3;
  var total = 0;
  var page = 1;
  function prevPage()
  {
    if (current_page > 1) {
      current_page--;
      changePageforPrevious(current_page, records_per_page);
    }
  }

  function nextPage()
  {
    if (current_page < numPages()) {
      current_page++;
      changePage(current_page, records_per_page);
    }
  }

  function changePage(page, records_per_page)
  {

    var listing_table = document.getElementById("listingTable");
    var page_span = document.getElementById("page");


    slike(page, records_per_page).then(function (response) {
      total = response.total;

     
      if (page <= 1) page = 1;
      if (page > numPages()) page = numPages();

      listing_table.innerHTML = "";

      objJson = response.slike;

      for (var i = (page-1) * records_per_page; i < (page * records_per_page); i++) {
        listing_table.innerHTML += `<img src="images${objJson[i]}" alt="Slika">`;
      }
      page_span.innerHTML = page;

      buttons();
    })

  }

  function changePageforPrevious(page, records_per_page)
  {
    var listing_table = document.getElementById("listingTable");
    var page_span = document.getElementById("page");


    
    if (page <= 1) page = 1;
    if (page > numPages()) page = numPages();

    listing_table.innerHTML = "";

    for (var i = (page-1) * records_per_page; i < (page * records_per_page); i++) {
      if (objJson[i]) {
        listing_table.innerHTML += `<img src="images${objJson[i]}" alt="Slika">`;
      }
    }
    page_span.innerHTML = page;

    buttons()

  }

  function numPages()
  {
    return Math.ceil(totalImages() / records_per_page);
  }

  function buttons() {
    var naprijed = document.getElementById("dugmeSljedeci");
    var nazad = document.getElementById("dugmePrethodni");
    if (current_page == 1) {
      nazad.disabled = true;
    } else {
      nazad.disabled = false;
    }

    if (current_page == numPages()) {
      naprijed.disabled= true;
    } else {
      naprijed.disabled = false;
    }
  }
  

  function totalImages() {
    return total;
  }



  return {
    ucitajPodatke1: ucitajZauzeca,
    changePage: changePage,
    nextPage: nextPage,
    prevPage: prevPage,
    buttons: buttons
  };
}());

