
window.onload = function() {
  Pozivi.changePage(1, 3);
};


