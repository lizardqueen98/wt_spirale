let assert = chai.assert;
let should = chai.should;

describe('Kalendar', function(){
    describe('obojiZauzeca()', function(){
        it("Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan", function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
            Kalendar.ucitajPodatke(primjer1, primjer2);
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"","","");
            let dani = document.getElementById("daniId").children;
            let neobojena = 0;
            for(let i = 0; i < dani.length; i++){
                if(dani[i].children[1].classList.contains("zauzeta")) break;
                neobojena++;
            }
            assert.equal(neobojena, dani.length);
        });
        it("Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće", function(){
            let zauzece =[{ dan : 0, semestar : "ljetni", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"}];
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
            Kalendar.ucitajPodatke(zauzece, []);
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"1-02","10:00","12:00");
            let dani = document.getElementById("daniId").children;
            let neobojena = 0;
            for(let i = 0; i < dani.length; i++){
                if(dani[i].children[1].classList.contains("zauzeta")) break;
                neobojena++;
            }
            assert.equal(neobojena, dani.length);
        });
        it("Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće", function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 8);
            Kalendar.ucitajPodatke(primjer1, primjer2);
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),8,"1-02","10:00","12:00");
            let dani = document.getElementById("daniId").children;
            let neobojena = 0;
            for(let i = 0; i < dani.length; i++){
                if(dani[i].children[1].classList.contains("zauzeta")) break;
                neobojena++;
            }
            assert.equal(neobojena, dani.length);
        });
        it("Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje", function(){
            let zauzeca = [{ dan : 0, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                            { dan : 1, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                            { dan : 2, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                            { dan : 3, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                            { dan : 4, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                            { dan : 5, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                            { dan : 6, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"}]
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
            Kalendar.ucitajPodatke(zauzeca, primjer2);
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"1-02","09:00","12:00");
            let dani = document.getElementById("daniId").children;
            let obojena = 0;
            for(let i = 0; i < dani.length; i++){
                if(dani[i].children[1].classList.contains("slobodna")) break;
                obojena++;
            }
            assert.equal(obojena, dani.length);
        });
        it("Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista", function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
            Kalendar.ucitajPodatke(primjer1, primjer2);
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"1-02","09:00","12:00");
            let dani = document.getElementById("daniId").children;
            let obojena1 = 0;
            for(let i = 0; i < dani.length; i++){
                if(dani[i].children[1].classList.contains("zauzeta")) break;
                obojena1++;
            }
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"1-02","09:00","12:00");
            dani = document.getElementById("daniId").children;
            let obojena2 = 0;
            for(let i = 0; i < dani.length; i++){
                if(dani[i].children[1].classList.contains("zauzeta")) break;
                obojena2++;
            }
            assert.equal(obojena1, obojena2);
        });
    });
    describe('iscrtajKalendar()', function(){
        it('Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana',function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 3);
            let dani = document.getElementById("daniId").children;
            assert.equal(dani.length, 30);
        });
        it('Pozivanje iscrtajKalendar za mjesec sa 31 dan: očekivano je da se prikaže 31 dan',function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 4);
            let dani = document.getElementById("daniId").children;
            assert.equal(dani.length, 31);
        });
        it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak',function(){
            let datum = new Date(Date.now());
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), datum.getMonth());
            let prvi = document.getElementById("daniId").children[0];
            assert.equal(parseInt(prvi.style.gridColumn, 10), 5);
        });
        it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu',function(){
            let datum = new Date(Date.now());
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), datum.getMonth());
            let dani = document.getElementById("daniId").children;
            let offset = parseInt(dani[0].style.gridColumn,10);
            assert.equal((offset-1+dani.length)%7, 6);
        });
        it('Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka',function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
            let dani = document.getElementById("daniId").children;
            let brojPrikazanih =0;
            for(let i = 0; i < dani.length; i++){
                if(parseInt(dani[i].children[0].innerHTML) != i+1) break;
                brojPrikazanih++;
            }
            assert.equal(brojPrikazanih, 31);
        });
        it('Očekivano je da se prikaže 28 dana za Februar',function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
            let dani = document.getElementById("daniId").children;
            assert.equal(dani.length, 28);
        });
        it('Očekivano je da je 30. dan u subotu za trenutni mjesec',function(){
            Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 5);
            let dani = document.getElementById("daniId").children;
            let offset = parseInt(dani[0].style.gridColumn,10);
            assert.equal((offset-1+dani.length)%7, 0);
        });
    });
});