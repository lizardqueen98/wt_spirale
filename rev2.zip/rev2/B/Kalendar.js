
var date = new Date();
var trenutniMjesec = date.getMonth();
var mjeseci = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
var sala = "0-01";
var pocetak = null;
var kraj = null;

// hardkodirani podaci

var pocetnaPeriodicna = [
		{ dan: 0, semestar: "zimski", pocetak: "12:00", kraj: "13:00", naziv: "1-04", predavac: "Novica" },
		{ dan: 1, semestar: "zimski", pocetak: "12:00",	kraj: "15:00", naziv: "1-04", predavac: "Juric"},
		{ dan: 2, semestar: "zimski", pocetak: "11:00",	kraj: "12:30", naziv: "1-04", predavac: "Juric"},
		{ dan: 6, semestar: "zimski", pocetak: "10:00",	kraj: "11:00", naziv: "1-04", predavac: "Juric"},
		{ dan: 5, semestar: "zimski", pocetak: "10:00",	kraj: "11:00", naziv: "0-04", predavac: "Juric"},
		{ dan: 6, semestar: "zimski", pocetak: "16:00",	kraj: "17:00", naziv: "0-04", predavac: "Juric"},
		{ dan: 1, semestar: "ljetni", pocetak: "12:00",	kraj: "15:00", naziv: "VA1", predavac: "Juric"},
		{ dan: 5, semestar: "ljetni", pocetak: "09:00",	kraj: "11:00", naziv: "VA1", predavac: "Juric"},
		{ dan: 4, semestar: "ljetni", pocetak: "15:00",	kraj: "18:00", naziv: "VA2", predavac: "Juric"},
		{ dan: 4, semestar: "ljetni", pocetak: "16:00",	kraj: "19:00", naziv: "VA2", predavac: "Juric"}
	];
	
var pocetnaVanredna = [
	{ datum: "12.01.2019", pocetak: "00:00", kraj: "01:30", naziv: "0-09", predavac: "Ja"},
	{ datum: "01.01.2019", pocetak: "01:00", kraj: "01:30", naziv: "0-09", predavac: "Ja"},
	{ datum: "25.12.2019", pocetak: "12:00", kraj: "13:00", naziv: "1-04", predavac: "Ja"},
	{ datum: "15.10.2019", pocetak: "23:00", kraj: "23:30", naziv: "1-04", predavac: "Ja"},
	{ datum: "27.02.2019", pocetak: "12:00", kraj: "13:00", naziv: "1-04", predavac: "Ja"},
	{ datum: "23.11.2019", pocetak: "14:15", kraj: "16:00", naziv: "1-04", predavac: "Ja"},
	{ datum: "24.11.2019", pocetak: "00:00", kraj: "00:01", naziv: "1-04", predavac: "Ja"}
];	


let Kalendar = (function()
{	
	_periodicna = [];
	_vanredna = [];
	
	function brisiZauzeca(kalendarRef, mjesec) {
		var brojDana = new Date(date.getFullYear(), mjesec + 1, 0).getDate();
		for (var i = 1; i <= brojDana; i++) {
			var danDiv = kalendarRef.querySelectorAll("#dan_" + i)[0];
			danDiv.children[1].className = "slobodna";
		}
	}	
	
	function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
		if (kalendarRef == null || mjesec == null || sala == null || pocetak == null || kraj == null) {
			return;
		}

		// brisi postojeca zauzeca
		brisiZauzeca(kalendarRef, mjesec);

		// boji periodicna zauzeca
		var perLength = _periodicna.length;
		for (var i = 0; i < perLength; i++) {
			if (trebaLiBojiti(_periodicna[i], true, mjesec, sala, pocetak, kraj)) {
				obojiPeriodicnuRez(_periodicna[i], kalendarRef, mjesec);
			}
		}
		// boji vanredna zauzeca 
		var vanLength = _vanredna.length;
		for (var i = 0; i < vanLength; i++) {
			if (trebaLiBojiti(_vanredna[i], false, mjesec, sala, pocetak, kraj)) {
				var dan = parseInt(_vanredna[i].datum.split(".")[0], 10);
				obojiVanrednuRez(_vanredna[i], kalendarRef, dan);
			}
		}		
	}
	
	function obojiPeriodicnuRez(rez, kalendarRef, mjesec)
	{
		var date = new Date();
		var dayofweek = new Date(date.getFullYear(), mjesec, 1).getDay();
		dayofweek = (dayofweek + 6) % 7;
		var brojDana = new Date(date.getFullYear(), mjesec + 1, 0).getDate();
		var i;
		if (rez.dan < dayofweek) {
			i = 7 - dayofweek + rez.dan + 1;
		} else {
			i = rez.dan - dayofweek + 1;
		}
		for (; i <= brojDana; i += 7) {
			var danDiv = kalendarRef.querySelectorAll("#dan_" + i)[0];
			danDiv.children[1].className = "zauzeta";
		}
	}
	
	function obojiVanrednuRez(rez, kalendarRef, dan) {
		var danDiv = kalendarRef.querySelectorAll("#dan_" + dan)[0];
		danDiv.children[1].className = "zauzeta";
	}

	function trebaLiBojiti(rez, periodicna, mjesec, sala, pocetak, kraj) {
		if (rez.naziv !== sala) {
			return false;
		}
		if (!((rez.pocetak <= pocetak && rez.kraj > pocetak) || (rez.pocetak >= pocetak && rez.pocetak < kraj))) {
			return false;
		}
		
		if (periodicna) {
			// provjera da li semestar odgovara mjesecu
			if (rez.semestar === "zimski" && mjesec > 0 && mjesec < 9) {
				return false;
			}
			if (rez.semestar === "ljetni" && (mjesec < 1 || mjesec > 5)) {
				return false;
			}
		} else {
			// provjeriti da li se datum nalazi u mjesecu
			var rezMjesec = parseInt(rez.datum.split('.')[1], 10) - 1;
			if (rezMjesec !== mjesec) {
				return false;
			}
		}
		// svi testovi prosli
		return true;		
	}
	
	function provjeriPeriodicno(p) {
		if (p.dan < 0 || p.dan > 6) {
			return false;			
		}
		if (p.semestar !== "zimski" && p.semestar !== "ljetni") {
			return false;
		}
		return true;
	}
	
	function ucitajPodatkeImpl(periodicna, vanredna){
		// brisi stare podatke
		_periodicna = [];
		_vanredna = [];
		
		var perLength = periodicna.length;
		for (var i = 0; i < perLength; i++) {
			if (provjeriPeriodicno(periodicna[i])) {
				_periodicna.push(periodicna[i]);
			}
		}
		
		var vanLength = vanredna.length;
		for (var i = 0; i < vanLength; i++) {
			_vanredna.push(vanredna[i]);

		}
	}
	
	function iscrtajKalendarImpl(kalendarRef, mjesec) 
	{		
		var dayofweek = new Date(date.getFullYear(), mjesec, 1).getDay();
		dayofweek = (dayofweek + 6) % 7;
		var brojDana = (new Date(date.getFullYear(), mjesec + 1, 0)).getDate();
		
		// izbrisati postojece dane;
		while (kalendarRef.firstChild) {
			kalendarRef.removeChild(kalendarRef.firstChild);
		}
		
		// dodati prazne dane
		for (var i = 0; i < dayofweek; i++) {
			var d = document.createElement("div");
			d.className = "prazanDan";
			kalendarRef.appendChild(d);		
		}
		
		// dodati stvarne dane
		for (var i = 0; i < brojDana; i++) {
			var d = document.createElement("div");
			d.id = "dan_" + (i + 1);
			var p = document.createElement("p");
			p.innerHTML = i + 1;
			d.appendChild(p);		
			var d2 = document.createElement("div");
			d2.className = "slobodna";
			d.appendChild(d2);
			kalendarRef.appendChild(d);
			
		}
	}

	return {
		obojiZauzeca: obojiZauzecaImpl,
		ucitajPodatke: ucitajPodatkeImpl,
		iscrtajKalendar: iscrtajKalendarImpl,
	}
} ());

// inicijalizacija
Kalendar.ucitajPodatke(pocetnaPeriodicna, pocetnaVanredna);

// event-handlers
{
	var kRef = document.getElementById("daniMjesec");
	var salaDropdown = document.getElementById("salaDropdown");
	salaDropdown.addEventListener("change", function(ev) {
		sala = salaDropdown.value;
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
	});
	
	var pocetakInput = document.getElementById("pocetak");
	pocetakInput.addEventListener("input", function(ev) {
		pocetak = pocetakInput.value;
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
	});
	
	var krajInput = document.getElementById("kraj");
	krajInput.addEventListener("input", function(ev) {
		kraj = krajInput.value;
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
	});
	
	function promijeniMjesec(inc) {
		trenutniMjesec += inc;
		var m = document.getElementById("naslovMjeseca");
		m.innerHTML = mjeseci[trenutniMjesec];
		var mjesecSadrzaj = document.getElementById("daniMjesec");
		Kalendar.iscrtajKalendar(mjesecSadrzaj, trenutniMjesec);
		Kalendar.obojiZauzeca(kRef, trenutniMjesec, sala, pocetak, kraj);
	}

	var prethodniButton = document.getElementById("prethodniButton");
	prethodniButton.addEventListener("click", function(ev) {
		sljedeciButton.disabled = false;		
		if (trenutniMjesec == 1) {
			// zabrani dugme ako je novi mjesec januar
			prethodniButton.disabled = true;
		}
		promijeniMjesec(-1);
	});

	var sljedeciButton = document.getElementById("sljedeciButton");
	sljedeciButton.addEventListener("click", function(ev) {
		prethodniButton.disabled = false;		
		if (trenutniMjesec == 10) {
			// zabrani dugme ako je novi mjesec decembar
			sljedeciButton.disabled = true;
		}
		promijeniMjesec(1);
	});
}

Kalendar.iscrtajKalendar(document.getElementById("daniMjesec"), 10);